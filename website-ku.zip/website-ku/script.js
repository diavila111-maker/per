
const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");
const contactBtn = document.getElementById("contactBtn");

// Membuka dan menutup menu pada perangkat mobile
menuToggle.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("active");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute(
    "aria-label",
    isOpen ? "Tutup menu" : "Buka menu"
  );
  menuToggle.textContent = isOpen ? "✕" : "☰";
});

// Menutup menu setelah tautan dipilih
navLinks.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("active");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.setAttribute("aria-label", "Buka menu");
    menuToggle.textContent = "☰";
  });
});

// Menampilkan tahun secara otomatis
document.getElementById("year").textContent =
  new Date().getFullYear();

// Interaksi tombol kontak
contactBtn.addEventListener("click", () => {
  alert("Terima kasih! Silakan tambahkan informasi kontak Anda di sini.");
});
